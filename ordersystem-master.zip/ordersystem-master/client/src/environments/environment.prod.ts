export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyAfbZejjjfNF-8A9mUqesRO9xLYGXSj7zo',
    authDomain: 'order-sprinter.firebaseapp.com',
    databaseURL: 'https://order-sprinter.firebaseio.com',
    projectId: 'order-sprinter',
    storageBucket: 'order-sprinter.appspot.com',
    messagingSenderId: '295337076444',
    appId: '1:295337076444:web:3e0c381bca0712be'
  }
};
