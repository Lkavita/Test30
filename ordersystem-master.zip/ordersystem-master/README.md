# Ordersystem

Ordersystem is a ordering system. Its structure is very simple and intuitive including only the most important features to work properly.



## UI

For more information regarding the user interface/frontend, head over to [its README](https://github.com/dorfingerjonas/ordersystem/tree/master/client#readme).

## Printer

If you are interested on how the printer connection works. You might be lucky [here](https://github.com/dorfingerjonas/ordersystem/tree/master/printer#readme).



<hr>

Copyright © 2021, Jonas Dorfinger. This software is [MIT licensed](./LICENSE).

